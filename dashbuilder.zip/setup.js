dashbuilder = {
  /*
		  // possible modes are EDITOR and CLIENT - if dashboards is set then CLIENT mode is assumed
		  mode: "CLIENT",
		  // The list of client dashboards - if CLIENT mode is used and no list is provided, than the dashboard "dashboard.yml" will be attempted to load. If no dashboard is found, then client opens for upload. 
		  // The dashboard can also be an URL
		  dashboards: [ "dashboard1.yaml", "dashboard2.json"],
	  
		  // base path to look for dashboards. Default is /
		  path: "/path",
	  	
		  // if true, then model from external urls will be allowed
		  allowExternal: true,
	  	
		  // A base URL for the samples repository 
		  // if set then dashbuilder tries to retrieve samples.json from root dir and load samples from the provided URL
		  samplesUrl: "/samples",
	  	
		  // An URL to resolve sample path on disk. It will receive a GET request with a query parameter called "sampleId"
		  samplesEditService: "edit"
	  */
};
